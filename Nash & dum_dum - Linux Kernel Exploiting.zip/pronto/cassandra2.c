#include <linux/cassandra2.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <asm/uaccess.h>
#include <linux/slab.h>

#define MAXBUFF   128

asmlinkage int sys_cassandra2(int len, char * buf) {
char *code = kmalloc(MAXBUFF, GFP_KERNEL);
if (code ==NULL) {
return 0;
 }

if (copy_from_user(code, buf, len)){
	return 0;
}
printk("GOT object at %p\n",code);
kfree(code);
return 0;
}

