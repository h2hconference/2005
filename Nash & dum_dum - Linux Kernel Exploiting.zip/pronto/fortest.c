/* Fortest - Interage com system call cassandra
 * para enviar format strings.
 * Nash Leon - nashleon@yahoo.com.br
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdio.h>
#include <errno.h>
#include <linux/cassandra.h>
#include "/usr/src/linux-2.6.10/include/asm/unistd.h"
#include  <linux/sysctl.h>

int main(int argc,char **argv){
char code[1024];
unsigned int len;

strcpy(code,argv[1]);
len = strlen(code)+1;

printf("testando format string...");
cassandra(len,code);
printf("OK.\ncheck dmesg\n");
return 0;
}
