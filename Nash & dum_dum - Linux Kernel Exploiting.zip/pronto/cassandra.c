#include <linux/cassandra.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <asm/uaccess.h>
#include <linux/slab.h>

#define MAXBUFF   512

static char vbuffer[256];
asmlinkage int vulneravel(int len,char *code) {
        char buf[256];
        memcpy(buf,code,len);
	snprintf(vbuffer,sizeof(vbuffer)-1,buf);
	printk("Output: %s\n",vbuffer);
	return 0;
}


asmlinkage int sys_cassandra(int len, char * buf) {

char *code = kmalloc(MAXBUFF, GFP_KERNEL);

if (code ==NULL) {
return 0;
 }

if (copy_from_user(code, buf, len)){
	return 0;
}
vulneravel(len,code);
return 0;
}

