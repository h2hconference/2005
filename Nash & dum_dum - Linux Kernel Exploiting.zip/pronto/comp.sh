gcc -D__KERNEL__ -DMODULE -I /usr/src/linux-2.6.10/include -O2 -c  $1.c

echo obj-m := $1.o > Makefile

make -C /usr/src/linux-2.6.10 SUBDIRS=$PWD modules
